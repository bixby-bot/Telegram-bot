import { describe, expect, it } from 'vitest';
import { trackingCode, normalizeDigits } from '../src/utils/tracking';
import { ecardPurchaseSchema } from '../src/validation';

describe('tracking codes', () => {
  it('generates the required prefixes and six digits', () => {
    for (const [prefix, re] of [['WR', /^WR-\d{6}$/], ['EC', /^EC-\d{6}$/], ['CARD', /^CARD-\d{6}$/]] as const) {
      expect(trackingCode(prefix)).toMatch(re);
    }
  });
});

describe('input normalization', () => {
  it('normalizes Persian digits', () => expect(normalizeDigits('۱۲۳۴۵')).toBe('12345'));
});

describe('ecard purchase validation', () => {
  const base = { identityValue: '123', email: 'a@example.com', phone: '0912', teamId: 'team', networkId: 'net' };
  it('accepts the 200-10000 USDT range', () => {
    expect(ecardPurchaseSchema.safeParse({ ...base, amount: 200 }).success).toBe(true);
    expect(ecardPurchaseSchema.safeParse({ ...base, amount: 10000 }).success).toBe(true);
  });
  it('rejects amounts outside the range', () => {
    expect(ecardPurchaseSchema.safeParse({ ...base, amount: 199.99 }).success).toBe(false);
    expect(ecardPurchaseSchema.safeParse({ ...base, amount: 10000.01 }).success).toBe(false);
  });
});
