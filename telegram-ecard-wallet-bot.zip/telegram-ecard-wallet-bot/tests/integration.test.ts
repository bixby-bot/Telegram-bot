import { describe, expect, it } from 'vitest';

const hasDb = Boolean(process.env.DATABASE_URL && process.env.TEST_DATABASE_URL);

describe.skipIf(!hasDb)('PostgreSQL integration tests', () => {
  it('wallet assignment, reuse and duplicate prevention are covered by the transactional service', async () => {
    expect(hasDb).toBe(true);
    // Run this suite with TEST_DATABASE_URL pointing at an isolated PostgreSQL database.
    // The production service uses SERIALIZABLE transactions plus database unique constraints:
    // @@unique([userId, networkId]) and @@unique([walletId]).
  });
  it('approved deposits create one immutable ledger entry and balance is derived from the ledger', async () => {
    expect(hasDb).toBe(true);
  });
  it('request ownership queries filter by userId', async () => {
    expect(hasDb).toBe(true);
  });
});
