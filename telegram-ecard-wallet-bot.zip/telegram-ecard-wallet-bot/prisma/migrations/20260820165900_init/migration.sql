-- Generated initial migration for PostgreSQL. Run with `prisma migrate deploy`.
CREATE TYPE "RequestStatus" AS ENUM ('PENDING','APPROVED','REJECTED','CANCELLED');
CREATE TYPE "DepositStatus" AS ENUM ('PENDING','APPROVED','REJECTED');
CREATE TYPE "LedgerType" AS ENUM ('DEPOSIT','ADJUSTMENT','WITHDRAWAL','REFUND');
CREATE TYPE "ConversationStatus" AS ENUM ('OPEN','CLOSED');
CREATE TYPE "MessageDirection" AS ENUM ('USER_TO_ADMIN','ADMIN_TO_USER');

CREATE TABLE "User" (
 "id" TEXT NOT NULL, "telegramId" BIGINT NOT NULL, "username" TEXT, "firstName" TEXT, "lastName" TEXT,
 "isBlocked" BOOLEAN NOT NULL DEFAULT false, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
 CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "User_telegramId_key" ON "User"("telegramId");

CREATE TABLE "Admin" (
 "id" TEXT NOT NULL, "telegramId" BIGINT NOT NULL, "active" BOOLEAN NOT NULL DEFAULT true, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
 CONSTRAINT "Admin_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "Admin_telegramId_key" ON "Admin"("telegramId");

CREATE TABLE "Team" (
 "id" TEXT NOT NULL, "name" TEXT NOT NULL, "active" BOOLEAN NOT NULL DEFAULT true, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
 CONSTRAINT "Team_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "Team_name_key" ON "Team"("name");

CREATE TABLE "Network" (
 "id" TEXT NOT NULL, "name" TEXT NOT NULL, "displayName" TEXT NOT NULL, "currency" TEXT NOT NULL DEFAULT 'USDT', "active" BOOLEAN NOT NULL DEFAULT true, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
 CONSTRAINT "Network_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "Network_name_key" ON "Network"("name");

CREATE TABLE "Wallet" (
 "id" TEXT NOT NULL, "networkId" TEXT NOT NULL, "currency" TEXT NOT NULL DEFAULT 'USDT', "address" TEXT NOT NULL, "active" BOOLEAN NOT NULL DEFAULT true, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
 CONSTRAINT "Wallet_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "Wallet_networkId_address_key" ON "Wallet"("networkId","address");
CREATE INDEX "Wallet_networkId_active_idx" ON "Wallet"("networkId","active");

CREATE TABLE "WalletAssignment" (
 "id" TEXT NOT NULL, "userId" TEXT NOT NULL, "walletId" TEXT NOT NULL, "networkId" TEXT NOT NULL, "assignedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT "WalletAssignment_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "WalletAssignment_walletId_key" ON "WalletAssignment"("walletId");
CREATE UNIQUE INDEX "WalletAssignment_userId_networkId_key" ON "WalletAssignment"("userId","networkId");
CREATE INDEX "WalletAssignment_userId_idx" ON "WalletAssignment"("userId");
CREATE INDEX "WalletAssignment_networkId_idx" ON "WalletAssignment"("networkId");

CREATE TABLE "WorkroomRequest" (
 "id" TEXT NOT NULL, "trackingCode" TEXT NOT NULL, "userId" TEXT NOT NULL, "irId" TEXT NOT NULL, "passwordEncrypted" TEXT NOT NULL, "qAccountPasswordEnc" TEXT NOT NULL, "email" TEXT NOT NULL, "emailPasswordEnc" TEXT NOT NULL, "phoneNumber" TEXT NOT NULL, "status" "RequestStatus" NOT NULL DEFAULT 'PENDING', "adminNote" TEXT, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
 CONSTRAINT "WorkroomRequest_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "WorkroomRequest_trackingCode_key" ON "WorkroomRequest"("trackingCode");
CREATE INDEX "WorkroomRequest_userId_createdAt_idx" ON "WorkroomRequest"("userId","createdAt");
CREATE INDEX "WorkroomRequest_status_createdAt_idx" ON "WorkroomRequest"("status","createdAt");

CREATE TABLE "EcardChangeRequest" (
 "id" TEXT NOT NULL, "trackingCode" TEXT NOT NULL, "userId" TEXT NOT NULL, "irId" TEXT NOT NULL, "email" TEXT NOT NULL, "phone" TEXT NOT NULL, "teamId" TEXT NOT NULL, "usdtAddress" TEXT NOT NULL, "networkId" TEXT NOT NULL, "ecardSerial" TEXT NOT NULL, "ecardPasswordEnc" TEXT NOT NULL, "status" "RequestStatus" NOT NULL DEFAULT 'PENDING', "adminNote" TEXT, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
 CONSTRAINT "EcardChangeRequest_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "EcardChangeRequest_trackingCode_key" ON "EcardChangeRequest"("trackingCode");
CREATE INDEX "EcardChangeRequest_userId_createdAt_idx" ON "EcardChangeRequest"("userId","createdAt");
CREATE INDEX "EcardChangeRequest_status_createdAt_idx" ON "EcardChangeRequest"("status","createdAt");

CREATE TABLE "EcardPurchaseRequest" (
 "id" TEXT NOT NULL, "trackingCode" TEXT NOT NULL, "userId" TEXT NOT NULL, "identityValue" TEXT NOT NULL, "email" TEXT NOT NULL, "phone" TEXT NOT NULL, "teamId" TEXT NOT NULL, "amount" DECIMAL(18,6) NOT NULL, "networkId" TEXT NOT NULL, "status" "RequestStatus" NOT NULL DEFAULT 'PENDING', "adminNote" TEXT, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
 CONSTRAINT "EcardPurchaseRequest_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "EcardPurchaseRequest_trackingCode_key" ON "EcardPurchaseRequest"("trackingCode");
CREATE INDEX "EcardPurchaseRequest_userId_createdAt_idx" ON "EcardPurchaseRequest"("userId","createdAt");
CREATE INDEX "EcardPurchaseRequest_status_createdAt_idx" ON "EcardPurchaseRequest"("status","createdAt");

CREATE TABLE "Deposit" (
 "id" TEXT NOT NULL, "trackingCode" TEXT NOT NULL, "userId" TEXT NOT NULL, "walletId" TEXT NOT NULL, "networkId" TEXT NOT NULL, "network" TEXT NOT NULL, "currency" TEXT NOT NULL, "address" TEXT NOT NULL, "amount" DECIMAL(18,6) NOT NULL, "status" "DepositStatus" NOT NULL DEFAULT 'PENDING', "txHash" TEXT, "note" TEXT, "approvedBy" BIGINT, "approvedAt" TIMESTAMP(3), "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT "Deposit_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "Deposit_trackingCode_key" ON "Deposit"("trackingCode");
CREATE INDEX "Deposit_userId_createdAt_idx" ON "Deposit"("userId","createdAt");
CREATE INDEX "Deposit_status_createdAt_idx" ON "Deposit"("status","createdAt");
CREATE INDEX "Deposit_walletId_idx" ON "Deposit"("walletId");

CREATE TABLE "LedgerTransaction" (
 "id" TEXT NOT NULL, "userId" TEXT NOT NULL, "type" "LedgerType" NOT NULL, "amount" DECIMAL(18,6) NOT NULL, "currency" TEXT NOT NULL DEFAULT 'USDT', "reference" TEXT NOT NULL, "requestId" TEXT, "depositId" TEXT, "createdBy" BIGINT, "note" TEXT, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT "LedgerTransaction_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "LedgerTransaction_reference_key" ON "LedgerTransaction"("reference");
CREATE UNIQUE INDEX "LedgerTransaction_depositId_key" ON "LedgerTransaction"("depositId");
CREATE INDEX "LedgerTransaction_userId_createdAt_idx" ON "LedgerTransaction"("userId","createdAt");
CREATE INDEX "LedgerTransaction_type_createdAt_idx" ON "LedgerTransaction"("type","createdAt");

CREATE TABLE "Conversation" (
 "id" TEXT NOT NULL, "userId" TEXT NOT NULL, "status" "ConversationStatus" NOT NULL DEFAULT 'OPEN', "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "closedAt" TIMESTAMP(3),
 CONSTRAINT "Conversation_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "Conversation_userId_status_idx" ON "Conversation"("userId","status");

CREATE TABLE "Message" (
 "id" TEXT NOT NULL, "conversationId" TEXT NOT NULL, "userId" TEXT NOT NULL, "direction" "MessageDirection" NOT NULL, "telegramMessageId" INTEGER, "body" TEXT NOT NULL, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT "Message_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "Message_conversationId_createdAt_idx" ON "Message"("conversationId","createdAt");
CREATE INDEX "Message_userId_createdAt_idx" ON "Message"("userId","createdAt");

CREATE TABLE "BotSetting" (
 "id" TEXT NOT NULL, "key" TEXT NOT NULL, "value" TEXT NOT NULL, "updatedAt" TIMESTAMP(3) NOT NULL,
 CONSTRAINT "BotSetting_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "BotSetting_key_key" ON "BotSetting"("key");

CREATE TABLE "AuditLog" (
 "id" TEXT NOT NULL, "userId" TEXT, "adminId" BIGINT, "action" TEXT NOT NULL, "entity" TEXT NOT NULL, "entityId" TEXT, "metadata" JSONB, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT "AuditLog_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "AuditLog_entity_entityId_idx" ON "AuditLog"("entity","entityId");
CREATE INDEX "AuditLog_createdAt_idx" ON "AuditLog"("createdAt");

CREATE TABLE "BotSession" (
 "id" TEXT NOT NULL, "userId" TEXT NOT NULL, "state" TEXT, "data" JSONB, "updatedAt" TIMESTAMP(3) NOT NULL,
 CONSTRAINT "BotSession_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "BotSession_userId_key" ON "BotSession"("userId");

ALTER TABLE "Wallet" ADD CONSTRAINT "Wallet_networkId_fkey" FOREIGN KEY ("networkId") REFERENCES "Network"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "WalletAssignment" ADD CONSTRAINT "WalletAssignment_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "WalletAssignment" ADD CONSTRAINT "WalletAssignment_walletId_fkey" FOREIGN KEY ("walletId") REFERENCES "Wallet"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "WalletAssignment" ADD CONSTRAINT "WalletAssignment_networkId_fkey" FOREIGN KEY ("networkId") REFERENCES "Network"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "WorkroomRequest" ADD CONSTRAINT "WorkroomRequest_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "EcardChangeRequest" ADD CONSTRAINT "EcardChangeRequest_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "EcardChangeRequest" ADD CONSTRAINT "EcardChangeRequest_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES "Team"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "EcardChangeRequest" ADD CONSTRAINT "EcardChangeRequest_networkId_fkey" FOREIGN KEY ("networkId") REFERENCES "Network"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "EcardPurchaseRequest" ADD CONSTRAINT "EcardPurchaseRequest_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "EcardPurchaseRequest" ADD CONSTRAINT "EcardPurchaseRequest_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES "Team"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "EcardPurchaseRequest" ADD CONSTRAINT "EcardPurchaseRequest_networkId_fkey" FOREIGN KEY ("networkId") REFERENCES "Network"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "Deposit" ADD CONSTRAINT "Deposit_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "Deposit" ADD CONSTRAINT "Deposit_walletId_fkey" FOREIGN KEY ("walletId") REFERENCES "Wallet"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "Deposit" ADD CONSTRAINT "Deposit_networkId_fkey" FOREIGN KEY ("networkId") REFERENCES "Network"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "LedgerTransaction" ADD CONSTRAINT "LedgerTransaction_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "LedgerTransaction" ADD CONSTRAINT "LedgerTransaction_depositId_fkey" FOREIGN KEY ("depositId") REFERENCES "Deposit"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "Conversation" ADD CONSTRAINT "Conversation_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "Message" ADD CONSTRAINT "Message_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES "Conversation"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "Message" ADD CONSTRAINT "Message_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "AuditLog" ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "BotSession" ADD CONSTRAINT "BotSession_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
