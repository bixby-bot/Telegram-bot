import Fastify from 'fastify';
import { env } from './config';
import { logger } from './lib/logger';
import { prisma } from './lib/prisma';

export async function startHttpServer() {
  const app = Fastify({ logger: false });
  app.get('/health', async (_request, reply) => {
    try { await prisma.$queryRaw`SELECT 1`; return reply.send({ status: 'ok' }); }
    catch { return reply.code(503).send({ status: 'error' }); }
  });
  app.get('/', async () => ({ service: 'telegram-ecard-wallet-management-bot', status: 'ok' }));
  await app.listen({ host: '0.0.0.0', port: env.PORT });
  logger.info({ port: env.PORT }, 'http server started');
  return app;
}
