import { env } from './config';
import { logger } from './lib/logger';
import { connectDatabase, disconnectDatabase } from './lib/prisma';
import { bootstrapDatabase } from './bootstrap';
import { bot } from './bot';
import { startHttpServer } from './http';

async function main() {
  if (!env.BOT_TOKEN || !env.DATABASE_URL) throw new Error('BOT_TOKEN and DATABASE_URL are required');
  await connectDatabase();
  await bootstrapDatabase();
  await startHttpServer();
  await bot.api.setMyCommands([{ command: 'start', description: 'شروع' }, { command: 'admin', description: 'پنل مدیریت' }]);
  await bot.start({ onStart: (info) => logger.info({ username: info.username }, 'telegram bot started') });
}

main().catch(async (err) => { logger.fatal({ err }, 'startup failed'); await disconnectDatabase().catch(() => undefined); process.exit(1); });

async function shutdown(signal: string) { logger.info({ signal }, 'shutting down'); await bot.stop(); await disconnectDatabase(); process.exit(0); }
process.once('SIGINT', () => void shutdown('SIGINT'));
process.once('SIGTERM', () => void shutdown('SIGTERM'));
