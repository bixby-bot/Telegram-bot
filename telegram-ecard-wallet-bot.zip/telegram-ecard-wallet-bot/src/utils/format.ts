import { Decimal } from '@prisma/client/runtime/library';

export function money(value: Decimal | number | string): string {
  const n = typeof value === 'number' ? value : Number(value.toString());
  return new Intl.NumberFormat('en-US', { maximumFractionDigits: 6 }).format(n);
}

export function statusFa(status: string): string {
  const map: Record<string, string> = {
    PENDING: 'در انتظار بررسی', APPROVED: 'تأیید شده', REJECTED: 'رد شده', CANCELLED: 'لغو شده',
    OPEN: 'باز', CLOSED: 'بسته شده'
  };
  return map[status] ?? status;
}
