import crypto from 'node:crypto';
import { env } from '../config';

const key = crypto.createHash('sha256').update(env.ENCRYPTION_KEY, 'utf8').digest();
const PREFIX = 'v1';

export function encrypt(plain: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ciphertext = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return [PREFIX, iv.toString('base64url'), tag.toString('base64url'), ciphertext.toString('base64url')].join('.');
}

export function decrypt(payload: string): string {
  const [prefix, ivB64, tagB64, cipherB64] = payload.split('.');
  if (prefix !== PREFIX || !ivB64 || !tagB64 || !cipherB64) throw new Error('Invalid encrypted payload');
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(ivB64, 'base64url'));
  decipher.setAuthTag(Buffer.from(tagB64, 'base64url'));
  return Buffer.concat([decipher.update(Buffer.from(cipherB64, 'base64url')), decipher.final()]).toString('utf8');
}
