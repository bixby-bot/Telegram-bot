import { randomInt } from 'node:crypto';

export function trackingCode(prefix: 'WR' | 'EC' | 'CARD' | 'DEP'): string {
  const n = randomInt(100000, 1000000);
  return `${prefix}-${n}`;
}

export function normalizeDigits(input: string): string {
  return input.replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))).trim();
}
