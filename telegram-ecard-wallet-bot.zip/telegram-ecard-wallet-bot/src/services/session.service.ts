import { prisma } from '../lib/prisma';

type SessionData = Record<string, unknown>;

export async function getSession(userId: string) {
  return prisma.botSession.findUnique({ where: { userId } });
}

export async function setSession(userId: string, state: string | null, data: SessionData = {}) {
  return prisma.botSession.upsert({ where: { userId }, create: { userId, state, data }, update: { state, data } });
}

export async function clearSession(userId: string) {
  await prisma.botSession.deleteMany({ where: { userId } });
}
