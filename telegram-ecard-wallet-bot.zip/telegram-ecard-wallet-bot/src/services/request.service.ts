import { prisma } from '../lib/prisma';
import { encrypt } from '../utils/crypto';
import { uniqueTrackingCode } from './tracking.service';

export async function createWorkroom(userId: string, input: { irId: string; password: string; qAccountPassword: string; email: string; emailPassword: string; phoneNumber: string }) {
  return prisma.workroomRequest.create({ data: { trackingCode: await uniqueTrackingCode('WR'), userId, irId: input.irId, passwordEncrypted: encrypt(input.password), qAccountPasswordEnc: encrypt(input.qAccountPassword), email: input.email, emailPasswordEnc: encrypt(input.emailPassword), phoneNumber: input.phoneNumber } });
}

export async function createEcardChange(userId: string, input: { irId: string; email: string; phone: string; teamId: string; usdtAddress: string; networkId: string; ecardSerial: string; ecardPassword: string }) {
  return prisma.ecardChangeRequest.create({ data: { trackingCode: await uniqueTrackingCode('EC'), userId, irId: input.irId, email: input.email, phone: input.phone, teamId: input.teamId, usdtAddress: input.usdtAddress, networkId: input.networkId, ecardSerial: input.ecardSerial, ecardPasswordEnc: encrypt(input.ecardPassword) } });
}

export async function createEcardPurchase(userId: string, input: { identityValue: string; email: string; phone: string; teamId: string; amount: number; networkId: string }) {
  return prisma.ecardPurchaseRequest.create({ data: { trackingCode: await uniqueTrackingCode('CARD'), userId, identityValue: input.identityValue, email: input.email, phone: input.phone, teamId: input.teamId, amount: input.amount, networkId: input.networkId } });
}

export async function userRequests(userId: string) {
  const [w, c, p] = await Promise.all([
    prisma.workroomRequest.findMany({ where: { userId }, orderBy: { createdAt: 'desc' }, take: 20 }),
    prisma.ecardChangeRequest.findMany({ where: { userId }, include: { team: true, network: true }, orderBy: { createdAt: 'desc' }, take: 20 }),
    prisma.ecardPurchaseRequest.findMany({ where: { userId }, include: { team: true, network: true }, orderBy: { createdAt: 'desc' }, take: 20 })
  ]);
  return { workroom: w, change: c, purchase: p };
}

export async function pendingRequests(limit = 20) {
  const [w, c, p] = await Promise.all([
    prisma.workroomRequest.findMany({ where: { status: 'PENDING' }, include: { user: true }, orderBy: { createdAt: 'asc' }, take: limit }),
    prisma.ecardChangeRequest.findMany({ where: { status: 'PENDING' }, include: { user: true, team: true, network: true }, orderBy: { createdAt: 'asc' }, take: limit }),
    prisma.ecardPurchaseRequest.findMany({ where: { status: 'PENDING' }, include: { user: true, team: true, network: true }, orderBy: { createdAt: 'asc' }, take: limit })
  ]);
  return { workroom: w, change: c, purchase: p };
}
