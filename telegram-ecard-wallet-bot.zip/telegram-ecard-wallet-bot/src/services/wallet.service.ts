import { Prisma } from '@prisma/client';
import { prisma } from '../lib/prisma';

export async function assignWallet(userId: string, networkId: string) {
  return prisma.$transaction(async (tx) => {
    const existing = await tx.walletAssignment.findUnique({ where: { userId_networkId: { userId, networkId } }, include: { wallet: true, network: true } });
    if (existing) return existing;

    const rows = await tx.$queryRaw<Array<{ id: string; networkId: string; currency: string; address: string }>>`
      SELECT w."id", w."networkId", w."currency", w."address"
      FROM "Wallet" w
      LEFT JOIN "WalletAssignment" wa ON wa."walletId" = w."id"
      WHERE w."networkId" = ${networkId} AND w."active" = true AND wa."id" IS NULL
      ORDER BY random()
      LIMIT 1
      FOR UPDATE SKIP LOCKED
    `;
    const wallet = rows[0];
    if (!wallet) throw new Error('NO_WALLET_AVAILABLE');

    try {
      return await tx.walletAssignment.create({
        data: { userId, networkId, walletId: wallet.id },
        include: { wallet: true, network: true }
      });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        const race = await tx.walletAssignment.findUnique({ where: { userId_networkId: { userId, networkId } }, include: { wallet: true, network: true } });
        if (race) return race;
      }
      throw error;
    }
  }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
}

export async function userWallets(userId: string) {
  return prisma.walletAssignment.findMany({ where: { userId }, include: { wallet: true, network: true }, orderBy: { assignedAt: 'asc' } });
}

export async function walletStats() {
  const networks = await prisma.network.findMany({ where: { active: true } });
  return Promise.all(networks.map(async (network) => {
    const [total, assigned] = await Promise.all([
      prisma.wallet.count({ where: { networkId: network.id, active: true } }),
      prisma.walletAssignment.count({ where: { networkId: network.id } })
    ]);
    return { network, total, assigned, available: total - assigned };
  }));
}
