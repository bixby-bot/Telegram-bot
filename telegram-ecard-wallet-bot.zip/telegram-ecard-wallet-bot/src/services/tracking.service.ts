import { prisma } from '../lib/prisma';
import { trackingCode } from '../utils/tracking';

export async function uniqueTrackingCode(prefix: 'WR' | 'EC' | 'CARD' | 'DEP'): Promise<string> {
  for (let i = 0; i < 10; i++) {
    const code = trackingCode(prefix);
    const [w, e, c, d] = await Promise.all([
      prisma.workroomRequest.count({ where: { trackingCode: code } }),
      prisma.ecardChangeRequest.count({ where: { trackingCode: code } }),
      prisma.ecardPurchaseRequest.count({ where: { trackingCode: code } }),
      prisma.deposit.count({ where: { trackingCode: code } })
    ]);
    if (w + e + c + d === 0) return code;
  }
  throw new Error('Unable to generate unique tracking code');
}
