import { prisma } from '../lib/prisma';
import { User } from '@prisma/client';

export async function upsertTelegramUser(from: { id: number; username?: string; first_name?: string; last_name?: string }): Promise<User> {
  return prisma.user.upsert({
    where: { telegramId: BigInt(from.id) },
    create: { telegramId: BigInt(from.id), username: from.username, firstName: from.first_name, lastName: from.last_name },
    update: { username: from.username, firstName: from.first_name, lastName: from.last_name }
  });
}

export async function getUserByTelegramId(telegramId: number) {
  return prisma.user.findUnique({ where: { telegramId: BigInt(telegramId) } });
}
