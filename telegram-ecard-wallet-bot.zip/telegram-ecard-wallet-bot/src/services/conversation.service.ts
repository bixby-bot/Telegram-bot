import { prisma } from '../lib/prisma';

export async function openConversation(userId: string) {
  const existing = await prisma.conversation.findFirst({ where: { userId, status: 'OPEN' }, orderBy: { createdAt: 'desc' } });
  return existing ?? prisma.conversation.create({ data: { userId } });
}

export async function closeConversation(userId: string) {
  return prisma.conversation.updateMany({ where: { userId, status: 'OPEN' }, data: { status: 'CLOSED', closedAt: new Date() } });
}

export async function saveMessage(conversationId: string, userId: string, direction: 'USER_TO_ADMIN' | 'ADMIN_TO_USER', body: string, telegramMessageId?: number) {
  return prisma.message.create({ data: { conversationId, userId, direction, body, telegramMessageId } });
}
