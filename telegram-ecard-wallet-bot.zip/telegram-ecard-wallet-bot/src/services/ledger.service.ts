import { Prisma } from '@prisma/client';
import { prisma } from '../lib/prisma';

export async function balance(userId: string, currency = 'USDT'): Promise<number> {
  const result = await prisma.ledgerTransaction.aggregate({ _sum: { amount: true }, where: { userId, currency } });
  return Number(result._sum.amount ?? 0);
}

export async function approveDeposit(depositId: string, adminId: bigint) {
  return prisma.$transaction(async (tx) => {
    const deposit = await tx.deposit.findUnique({ where: { id: depositId } });
    if (!deposit) throw new Error('DEPOSIT_NOT_FOUND');
    if (deposit.status !== 'PENDING') throw new Error('DEPOSIT_ALREADY_PROCESSED');
    const updated = await tx.deposit.update({ where: { id: depositId }, data: { status: 'APPROVED', approvedBy: adminId, approvedAt: new Date() } });
    await tx.ledgerTransaction.create({
      data: { userId: deposit.userId, type: 'DEPOSIT', amount: deposit.amount, currency: deposit.currency, reference: `DEP-${deposit.trackingCode}`, requestId: deposit.trackingCode, depositId: deposit.id, createdBy: adminId }
    });
    return updated;
  }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
}

export async function rejectDeposit(depositId: string, adminId: bigint, note?: string) {
  return prisma.deposit.update({ where: { id: depositId }, data: { status: 'REJECTED', approvedBy: adminId, approvedAt: new Date(), note } });
}
