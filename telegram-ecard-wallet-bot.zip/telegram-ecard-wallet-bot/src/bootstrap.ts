import { adminIds } from './config';
import { prisma } from './lib/prisma';
import { logger } from './lib/logger';

export async function bootstrapDatabase() {
  for (const telegramId of adminIds) {
    await prisma.admin.upsert({ where: { telegramId }, create: { telegramId }, update: { active: true } });
  }
  const count = await prisma.network.count();
  if (count === 0) {
    await prisma.network.createMany({ data: [
      { name: 'TRC20', displayName: 'USDT / TRC20', currency: 'USDT' },
      { name: 'ERC20', displayName: 'USDT / ERC20', currency: 'USDT' },
      { name: 'BEP20', displayName: 'USDT / BEP20', currency: 'USDT' },
      { name: 'POLYGON', displayName: 'USDT / POLYGON', currency: 'USDT' },
      { name: 'TON', displayName: 'USDT / TON', currency: 'USDT' }
    ] });
    logger.info('default networks seeded');
  }
}
