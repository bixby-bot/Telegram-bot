import { Bot, Context, InlineKeyboard } from 'grammy';
import QRCode from 'qrcode';
import { env, adminIds } from '../config';
import { prisma } from '../lib/prisma';
import { logger } from '../lib/logger';
import { rateLimit } from '../middleware/rateLimit';
import { isAdmin } from '../middleware/admin';
import { upsertTelegramUser } from '../services/user.service';
import { clearSession, getSession, setSession } from '../services/session.service';
import { createEcardChange, createEcardPurchase, createWorkroom, userRequests, pendingRequests } from '../services/request.service';
import { assignWallet, userWallets, walletStats } from '../services/wallet.service';
import { balance, approveDeposit, rejectDeposit } from '../services/ledger.service';
import { openConversation, closeConversation, saveMessage } from '../services/conversation.service';
import { ecardChangeSchema, ecardPurchaseSchema, workroomSchema, depositAmountSchema } from '../validation';
import { money, statusFa } from '../utils/format';
import { mainMenu, cancelKeyboard } from './keyboards';
import { cancelled, unavailable, welcome } from './text';

const bot = new Bot(env.BOT_TOKEN);

type SessionPayload = { flow?: string; step?: string; data?: Record<string, string>; adminTargetUserId?: string; adminAction?: string; requestId?: string; };

async function ensureUser(ctx: Context) {
  if (!ctx.from) throw new Error('Missing Telegram user');
  return upsertTelegramUser(ctx.from);
}

async function notifyAdmins(text: string, keyboard?: InlineKeyboard) {
  for (const id of adminIds) {
    try { await bot.api.sendMessage(Number(id), text, { reply_markup: keyboard }); } catch (err) { logger.warn({ err, adminId: id.toString() }, 'admin notification failed'); }
  }
}

async function notifyUser(telegramId: bigint, text: string, keyboard?: InlineKeyboard) {
  try { await bot.api.sendMessage(Number(telegramId), text, { reply_markup: keyboard }); } catch (err) { logger.warn({ err, telegramId: telegramId.toString() }, 'user notification failed'); }
}

async function prompt(ctx: Context, userId: string, flow: string, step: string, data: Record<string,string>, text: string) {
  await setSession(userId, `${flow}:${step}`, { flow, step, data });
  await ctx.reply(text, { reply_markup: cancelKeyboard() });
}

function adminMenu() {
  return new InlineKeyboard()
    .text('👥 کاربران', 'admin:users').text('📥 درخواست‌های جدید', 'admin:requests').row()
    .text('🔗 اتصال اتاق کار', 'admin:req:workroom').text('💳 چنچ ایکارت', 'admin:req:change').row()
    .text('🪪 تهیه ایکارت', 'admin:req:purchase').text('💰 واریزی‌ها', 'admin:deposits').row()
    .text('👛 موجودی کاربران', 'admin:balances').text('🏦 مدیریت کیف پول‌ها', 'admin:wallets').row()
    .text('🌐 شبکه‌ها', 'admin:networks').text('👥 تیم‌ها', 'admin:teams').row()
    .text('💬 پیام‌ها', 'admin:messages').text('📊 گزارش‌ها', 'admin:reports').row()
    .text('⚙️ تنظیمات', 'admin:settings').row()
    .text('⬅️ منوی اصلی', 'menu:home');
}

function backAdmin() { return new InlineKeyboard().text('⬅️ پنل مدیریت', 'admin:menu'); }

bot.use(rateLimit);
bot.use(async (ctx, next) => {
  if (ctx.from) await ensureUser(ctx);
  await next();
});

bot.command('start', async (ctx) => {
  await ctx.reply(welcome, { reply_markup: mainMenu(ctx) });
});
bot.command('admin', async (ctx) => {
  if (!isAdmin(ctx)) return ctx.reply('⛔️ دسترسی غیرمجاز است.');
  await ctx.reply('⚙️ پنل مدیریت', { reply_markup: adminMenu() });
});

bot.callbackQuery('flow:cancel', async (ctx) => {
  await ctx.answerCallbackQuery();
  const u = await ensureUser(ctx);
  await clearSession(u.id);
  await ctx.reply(cancelled, { reply_markup: mainMenu(ctx) });
});

bot.callbackQuery('menu:home', async (ctx) => { await ctx.answerCallbackQuery(); await clearSession((await ensureUser(ctx)).id); await ctx.reply(welcome, { reply_markup: mainMenu(ctx) }); });

bot.callbackQuery('menu:workroom', async (ctx) => {
  await ctx.answerCallbackQuery(); const u = await ensureUser(ctx);
  await prompt(ctx,u.id,'workroom','irId',{},'🔗 اتصال اتاق کار\n\nلطفاً IR ID را وارد کنید:');
});
bot.callbackQuery('menu:change', async (ctx) => {
  await ctx.answerCallbackQuery(); const u = await ensureUser(ctx);
  await prompt(ctx,u.id,'change','irId',{},'💳 چنچ ایکارت\n\nIR ID را وارد کنید:');
});
bot.callbackQuery('menu:purchase', async (ctx) => {
  await ctx.answerCallbackQuery(); const u = await ensureUser(ctx);
  await prompt(ctx,u.id,'purchase','identityValue',{},'🪪 تهیه ایکارت\n\nIR ID، کد ملی یا شماره پاسپورت را وارد کنید:');
});

bot.callbackQuery('menu:wallets', async (ctx) => {
  await ctx.answerCallbackQuery(); const u = await ensureUser(ctx);
  const [assigned, networks] = await Promise.all([userWallets(u.id), prisma.network.findMany({ where: { active: true }, orderBy: { displayName: 'asc' } })]);
  const assignedNetworkIds = new Set(assigned.map((a) => a.networkId));
  const kb = new InlineKeyboard();
  assigned.forEach((a) => kb.text(`💳 ${a.network.currency} / ${a.network.displayName}`, `wallet:network:${a.network.id}`).row());
  networks.filter((n) => !assignedNetworkIds.has(n.id)).forEach((n) => kb.text(`➕ ${n.currency} / ${n.displayName}`, `wallet:network:${n.id}`).row());
  if (!kb.inline_keyboard.length) return ctx.reply('هنوز شبکه فعالی تنظیم نشده است.');
  await ctx.reply('💰 کیف پول‌های شما و شبکه‌های قابل دریافت:', { reply_markup: kb });
});

bot.callbackQuery(/^wallet:network:(.+)$/, async (ctx) => {
  await ctx.answerCallbackQuery(); const u = await ensureUser(ctx); const networkId = ctx.match[1];
  try {
    const a = await assignWallet(u.id, networkId);
    const qr = await QRCode.toBuffer(a.wallet.address, { width: 500, margin: 2 });
    await ctx.reply(`💰 ${a.network.currency} / ${a.network.displayName}\n\nآدرس کیف پول:\n<code>${escapeHtml(a.wallet.address)}</code>\n\n⚠️ فقط ${a.network.currency} را با شبکه ${a.network.displayName} ارسال کنید.`, { parse_mode: 'HTML' });
    await ctx.replyWithPhoto(new Uint8Array(qr), { caption: 'QR Code آدرس کیف پول' });
  } catch (err) {
    if (err instanceof Error && err.message === 'NO_WALLET_AVAILABLE') return ctx.reply(unavailable);
    throw err;
  }
});

bot.callbackQuery('menu:balance', async (ctx) => { await ctx.answerCallbackQuery(); const u = await ensureUser(ctx); const b = await balance(u.id); await ctx.reply(`👛 موجودی کیف پول شما:\n\n<b>${money(b)} USDT</b>`, { parse_mode: 'HTML' }); });

bot.callbackQuery('menu:tracking', async (ctx) => {
  await ctx.answerCallbackQuery(); const u = await ensureUser(ctx); const r = await userRequests(u.id);
  const lines = [
    ...r.purchase.map(x => `🪪 <b>${x.trackingCode}</b>\n${money(x.amount)} USDT — ${statusFa(x.status)}`),
    ...r.change.map(x => `💳 <b>${x.trackingCode}</b>\nچنچ ایکارت — ${statusFa(x.status)}`),
    ...r.workroom.map(x => `🔗 <b>${x.trackingCode}</b>\nاتصال اتاق کار — ${statusFa(x.status)}`)
  ];
  await ctx.reply(lines.length ? `📋 درخواست‌های شما:\n\n${lines.join('\n\n')}` : 'درخواستی ثبت نشده است.', { parse_mode: 'HTML' });
});

bot.callbackQuery('menu:support', async (ctx) => {
  await ctx.answerCallbackQuery(); const u = await ensureUser(ctx); await openConversation(u.id);
  await ctx.reply('💬 گفت‌وگو با پشتیبانی باز شد. پیام خود را ارسال کنید. برای بستن گفت‌وگو از دکمه زیر استفاده کنید.', { reply_markup: new InlineKeyboard().text('بستن گفت‌وگو', 'support:close') });
  await notifyAdmins(`💬 کاربر جدید پیام پشتیبانی باز کرد.\nTelegram ID: ${u.telegramId.toString()}`, new InlineKeyboard().text('مشاهده پیام‌ها', `admin:conv:${u.id}`));
});
bot.callbackQuery('support:close', async (ctx) => { await ctx.answerCallbackQuery(); const u = await ensureUser(ctx); await closeConversation(u.id); await ctx.reply('گفت‌وگو بسته شد.', { reply_markup: mainMenu(ctx) }); });

async function handleFlow(ctx: Context, u: Awaited<ReturnType<typeof ensureUser>>, session: SessionPayload, text: string) {
  const flow = session.flow; const step = session.step; const data = session.data ?? {};
  if (!flow || !step) return false;
  try {
    if (flow === 'workroom') {
      if (step === 'irId') { data.irId = text; return prompt(ctx,u.id,flow,'password',data,'رمز عبور را وارد کنید:'); }
      if (step === 'password') { data.password = text; return prompt(ctx,u.id,flow,'qAccountPassword',data,'رمز Q Account را وارد کنید:'); }
      if (step === 'qAccountPassword') { data.qAccountPassword = text; return prompt(ctx,u.id,flow,'email',data,'ایمیل را وارد کنید:'); }
      if (step === 'email') { data.email = text; return prompt(ctx,u.id,flow,'emailPassword',data,'رمز ایمیل را وارد کنید:'); }
      if (step === 'emailPassword') { data.emailPassword = text; return prompt(ctx,u.id,flow,'phoneNumber',data,'شماره تلفن را وارد کنید:'); }
      if (step === 'phoneNumber') {
        data.phoneNumber = text; const parsed = workroomSchema.safeParse(data); if (!parsed.success) { return ctx.reply('❌ اطلاعات واردشده معتبر نیست. لطفاً عملیات را از ابتدا انجام دهید.', { reply_markup: mainMenu(ctx) }); }
        const req = await createWorkroom(u.id, parsed.data); await clearSession(u.id);
        await ctx.reply(`✅ درخواست اتصال اتاق کار ثبت شد.\n\nکد پیگیری: <b>${req.trackingCode}</b>\nوضعیت: ${statusFa(req.status)}`, { parse_mode: 'HTML', reply_markup: mainMenu(ctx) });
        await notifyAdmins(`🔗 درخواست اتصال اتاق کار\nکد: ${req.trackingCode}\nکاربر: ${u.telegramId.toString()}\nIR ID: ${escapeHtml(req.irId)}\nایمیل: ${escapeHtml(req.email)}\nتلفن: ${escapeHtml(req.phoneNumber)}\nرمزها: [محفوظ و رمزنگاری‌شده]`, requestKeyboard('workroom',req.id)); return true;
      }
    }
    if (flow === 'change') {
      if (step === 'irId') { data.irId = text; return prompt(ctx,u.id,flow,'email',data,'ایمیل را وارد کنید:'); }
      if (step === 'email') { data.email = text; return prompt(ctx,u.id,flow,'phone',data,'شماره تلفن را وارد کنید:'); }
      if (step === 'phone') { data.phone = text; return chooseTeam(ctx,u.id,flow,data); }
      if (step === 'team') { data.teamId = text; return prompt(ctx,u.id,flow,'usdtAddress',data,'آدرس USDT را وارد کنید:'); }
      if (step === 'usdtAddress') { data.usdtAddress = text; return chooseNetwork(ctx,u.id,flow,data,'شبکه USDT را انتخاب کنید:'); }
      if (step === 'network') { data.networkId = text; return prompt(ctx,u.id,flow,'ecardSerial',data,'سریال ایکارت را وارد کنید:'); }
      if (step === 'ecardSerial') { data.ecardSerial = text; return prompt(ctx,u.id,flow,'ecardPassword',data,'رمز ایکارت را وارد کنید:'); }
      if (step === 'ecardPassword') {
        data.ecardPassword = text; const parsed = ecardChangeSchema.safeParse(data); if (!parsed.success) return ctx.reply('❌ اطلاعات معتبر نیست. عملیات را دوباره انجام دهید.', { reply_markup: mainMenu(ctx) });
        const req = await createEcardChange(u.id, parsed.data); await clearSession(u.id);
        await ctx.reply(`✅ درخواست چنچ ایکارت ثبت شد.\n\nکد پیگیری: <b>${req.trackingCode}</b>\nوضعیت: ${statusFa(req.status)}`, { parse_mode: 'HTML', reply_markup: mainMenu(ctx) });
        await notifyAdmins(`💳 درخواست چنچ ایکارت\nکد: ${req.trackingCode}\nکاربر: ${u.telegramId.toString()}\nIR ID: ${escapeHtml(req.irId)}\nایمیل: ${escapeHtml(req.email)}\nشبکه: ${escapeHtml((await prisma.network.findUnique({where:{id:req.networkId}}))?.displayName ?? '')}\nرمز ایکارت: [محفوظ و رمزنگاری‌شده]`, requestKeyboard('change',req.id)); return true;
      }
    }
    if (flow === 'purchase') {
      if (step === 'identityValue') { data.identityValue = text; return prompt(ctx,u.id,flow,'email',data,'ایمیل را وارد کنید:'); }
      if (step === 'email') { data.email = text; return prompt(ctx,u.id,flow,'phone',data,'شماره تلفن را وارد کنید:'); }
      if (step === 'phone') { data.phone = text; return chooseTeam(ctx,u.id,flow,data); }
      if (step === 'team') { data.teamId = text; return prompt(ctx,u.id,flow,'amount',data,'مبلغ درخواستی را به USDT وارد کنید (حداقل 200 و حداکثر 10000):'); }
      if (step === 'amount') { data.amount = text; return chooseNetwork(ctx,u.id,flow,data,'شبکه واریز USDT را انتخاب کنید:'); }
      if (step === 'network') {
        data.networkId = text; const parsed = ecardPurchaseSchema.safeParse(data); if (!parsed.success) return ctx.reply('❌ مبلغ باید بین 200 تا 10000 USDT باشد و سایر اطلاعات نیز معتبر باشند.', { reply_markup: mainMenu(ctx) });
        const req = await createEcardPurchase(u.id, parsed.data); let assignment;
        try { assignment = await assignWallet(u.id, req.networkId); } catch (err) { if (err instanceof Error && err.message === 'NO_WALLET_AVAILABLE') { await prisma.ecardPurchaseRequest.update({where:{id:req.id},data:{status:'REJECTED',adminNote:'No wallet available'}}); return ctx.reply(unavailable,{reply_markup:mainMenu(ctx)}); } throw err; }
        await clearSession(u.id);
        const qr = await QRCode.toBuffer(assignment.wallet.address, { width: 500, margin: 2 });
        await ctx.reply(`✅ درخواست تهیه ایکارت ثبت شد.\n\nکد پیگیری: <b>${req.trackingCode}</b>\nمبلغ: <b>${money(req.amount)} USDT</b>\nشبکه: ${escapeHtml(assignment.network.displayName)}\nآدرس واریز:\n<code>${escapeHtml(assignment.wallet.address)}</code>\n\n⚠️ فقط USDT را با شبکه انتخاب‌شده ارسال کنید.`, { parse_mode: 'HTML', reply_markup: mainMenu(ctx) });
        await ctx.replyWithPhoto(new Uint8Array(qr), { caption: 'QR Code آدرس واریز' });
        await notifyAdmins(`🪪 درخواست تهیه ایکارت\nکد: ${req.trackingCode}\nکاربر: ${u.telegramId.toString()}\nمبلغ: ${money(req.amount)} USDT\nشبکه: ${escapeHtml(assignment.network.displayName)}\nآدرس: ${escapeHtml(assignment.wallet.address)}`, requestKeyboard('purchase',req.id)); return true;
      }
    }
  } catch (err) { logger.error({ err, flow, step, userId: u.id }, 'flow failed'); await clearSession(u.id); await ctx.reply('❌ خطایی رخ داد. لطفاً دوباره تلاش کنید.', { reply_markup: mainMenu(ctx) }); return true; }
  return false;
}

async function chooseTeam(ctx: Context, userId: string, flow: string, data: Record<string,string>) {
  const teams = await prisma.team.findMany({ where: { active: true }, orderBy: { name: 'asc' } });
  if (!teams.length) { await clearSession(userId); return ctx.reply('هنوز تیم فعالی تنظیم نشده است.', { reply_markup: mainMenu(ctx) }); }
  const kb = new InlineKeyboard(); teams.forEach(t => kb.text(t.name, `flow:${flow}:team:${t.id}`).row());
  await setSession(userId, `${flow}:team`, { flow, step: 'team', data }); await ctx.reply('تیم را انتخاب کنید:', { reply_markup: kb });
}
async function chooseNetwork(ctx: Context, userId: string, flow: string, data: Record<string,string>, title: string) {
  const networks = await prisma.network.findMany({ where: { active: true }, orderBy: { displayName: 'asc' } });
  if (!networks.length) { await clearSession(userId); return ctx.reply('هنوز شبکه فعالی تنظیم نشده است.', { reply_markup: mainMenu(ctx) }); }
  const kb = new InlineKeyboard(); networks.forEach(n => kb.text(`${n.currency} / ${n.displayName}`, `flow:${flow}:network:${n.id}`).row());
  const nextStep = flow === 'change' ? 'network' : 'network'; await setSession(userId, `${flow}:${nextStep}`, { flow, step: nextStep, data }); await ctx.reply(title, { reply_markup: kb });
}

bot.callbackQuery(/^flow:(workroom|change|purchase):team:(.+)$/, async (ctx) => { await ctx.answerCallbackQuery(); const u = await ensureUser(ctx); const flow = ctx.match[1]; const teamId=ctx.match[2]; const s=await getSession(u.id); if(!s) return; const p=s.data as SessionPayload; const data=(p?.data??{}) as Record<string,string>; data.teamId=teamId; const next=flow==='change'?'usdtAddress':'amount'; await prompt(ctx,u.id,flow,next,data,flow==='change'?'آدرس USDT را وارد کنید:':'مبلغ درخواستی را به USDT وارد کنید (حداقل 200 و حداکثر 10000):'); });
bot.callbackQuery(/^flow:(change|purchase):network:(.+)$/, async (ctx) => { await ctx.answerCallbackQuery(); const u=await ensureUser(ctx); const flow=ctx.match[1]; const networkId=ctx.match[2]; const s=await getSession(u.id); if(!s)return; const p=s.data as SessionPayload; const data=(p?.data??{}) as Record<string,string>; data.networkId=networkId; const next=flow==='change'?'ecardSerial':'__submit'; if(next==='ecardSerial') return prompt(ctx,u.id,flow,next,data,'سریال ایکارت را وارد کنید:'); const parsed=ecardPurchaseSchema.safeParse(data); if(!parsed.success)return ctx.reply('❌ اطلاعات یا مبلغ معتبر نیست.',{reply_markup:mainMenu(ctx)}); const req=await createEcardPurchase(u.id,parsed.data); try { const a=await assignWallet(u.id,networkId); await clearSession(u.id); const qr=await QRCode.toBuffer(a.wallet.address,{width:500,margin:2}); await ctx.reply(`✅ درخواست ثبت شد.\nکد پیگیری: <b>${req.trackingCode}</b>\nمبلغ: <b>${money(req.amount)} USDT</b>\nشبکه: ${escapeHtml(a.network.displayName)}\nآدرس: <code>${escapeHtml(a.wallet.address)}</code>\n\n⚠️ فقط USDT را با شبکه انتخاب‌شده ارسال کنید.`,{parse_mode:'HTML',reply_markup:mainMenu(ctx)}); await ctx.replyWithPhoto(new Uint8Array(qr),{caption:'QR Code آدرس واریز'}); await notifyAdmins(`🪪 درخواست تهیه ایکارت\nکد: ${req.trackingCode}\nکاربر: ${u.telegramId.toString()}\nمبلغ: ${money(req.amount)} USDT\nشبکه: ${escapeHtml(a.network.displayName)}\nآدرس: ${escapeHtml(a.wallet.address)}`,requestKeyboard('purchase',req.id)); } catch(err) { await prisma.ecardPurchaseRequest.update({where:{id:req.id},data:{status:'REJECTED',adminNote:'No wallet available'}}); if(err instanceof Error&&err.message==='NO_WALLET_AVAILABLE') return ctx.reply(unavailable,{reply_markup:mainMenu(ctx)}); throw err; } });

function requestKeyboard(kind: string, id: string) { return new InlineKeyboard().text('✅ تأیید',`admin:req:${kind}:approve:${id}`).text('❌ رد',`admin:req:${kind}:reject:${id}`).row().text('💬 پیام به کاربر',`admin:req:${kind}:message:${id}`).text('🗨 گفت‌وگو',`admin:req:${kind}:conversation:${id}`); }

bot.on('message:text', async (ctx) => {
  const u = await ensureUser(ctx); const text = ctx.message.text.trim(); const session = await getSession(u.id);
  if (session?.state) { const p=session.data as SessionPayload; if(await handleFlow(ctx,u,p,text)) return; }
  const conv = await prisma.conversation.findFirst({where:{userId:u.id,status:'OPEN'},orderBy:{createdAt:'desc'}});
  if (conv && !text.startsWith('/')) { await saveMessage(conv.id,u.id,'USER_TO_ADMIN',text,ctx.message.message_id); await notifyAdmins(`💬 پیام کاربر ${u.telegramId.toString()}:\n${escapeHtml(text)}`,new InlineKeyboard().text('مشاهده گفتگو',`admin:conv:${u.id}`)); return; }
  await ctx.reply('از منوی زیر استفاده کنید:',{reply_markup:mainMenu(ctx)});
});

// Admin panel
bot.callbackQuery('admin:menu', async (ctx)=>{await ctx.answerCallbackQuery(); if(!isAdmin(ctx))return ctx.reply('⛔️ دسترسی غیرمجاز است.'); await ctx.reply('⚙️ پنل مدیریت',{reply_markup:adminMenu()});});
bot.callbackQuery('admin:users', async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const count=await prisma.user.count();await ctx.reply(`👥 تعداد کاربران: ${count}`,{reply_markup:backAdmin()});});
bot.callbackQuery('admin:requests', async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const r=await pendingRequests(10);const total=r.workroom.length+r.change.length+r.purchase.length;await ctx.reply(`📥 درخواست‌های جدید: ${total}\n\nاتاق کار: ${r.workroom.length}\nچنچ ایکارت: ${r.change.length}\nتهیه ایکارت: ${r.purchase.length}`,{reply_markup:new InlineKeyboard().text('اتاق کار','admin:req:workroom').text('چنچ','admin:req:change').row().text('تهیه ایکارت','admin:req:purchase').text('⬅️ پنل','admin:menu')});});

for (const kind of ['workroom','change','purchase'] as const) {
  bot.callbackQuery(`admin:req:${kind}`, async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const r=await pendingRequests(20);const arr=kind==='workroom'?r.workroom:kind==='change'?r.change:r.purchase; if(!arr.length)return ctx.reply('موردی وجود ندارد.',{reply_markup:backAdmin()}); for(const x of arr){ const amount='amount' in x?`\nمبلغ: ${money(x.amount)} USDT`:''; await ctx.reply(`📌 <b>${x.trackingCode}</b>\nکاربر: ${x.user.telegramId.toString()}${amount}\nثبت: ${x.createdAt.toLocaleString('fa-IR')}`,{parse_mode:'HTML',reply_markup:requestKeyboard(kind,x.id)}); }});
}

async function getRequest(kind:string,id:string){if(kind==='workroom')return prisma.workroomRequest.findUnique({where:{id},include:{user:true}});if(kind==='change')return prisma.ecardChangeRequest.findUnique({where:{id},include:{user:true,team:true,network:true}});return prisma.ecardPurchaseRequest.findUnique({where:{id},include:{user:true,team:true,network:true}});}

for (const kind of ['workroom','change','purchase'] as const) {
  bot.callbackQuery(new RegExp(`^admin:req:${kind}:(approve|reject):(.+)$`),async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const action=ctx.match[1];const id=ctx.match[2];const table=kind==='workroom'?prisma.workroomRequest:kind==='change'?prisma.ecardChangeRequest:prisma.ecardPurchaseRequest;const req=await getRequest(kind,id);if(!req)return ctx.reply('درخواست پیدا نشد.');if(req.status!=='PENDING')return ctx.reply('این درخواست قبلاً پردازش شده است.');await table.update({where:{id},data:{status:action==='approve'?'APPROVED':'REJECTED'}});await notifyUser(req.user.telegramId,`درخواست <b>${req.trackingCode}</b> ${action==='approve'?'تأیید شد ✅':'رد شد ❌'}`,mainMenu(ctx));await ctx.reply('عملیات انجام شد.',{reply_markup:backAdmin()});});
  bot.callbackQuery(new RegExp(`^admin:req:${kind}:message:(.+)$`),async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const id=ctx.match[1];const req=await getRequest(kind,id);if(!req)return ctx.reply('درخواست پیدا نشد.');const u=await prisma.user.findUnique({where:{id:req.userId}});if(!u)return;await setSession(`admin:${ctx.from!.id}`,`admin_message:${u.id}`,{flow:'admin_message',step:'text',data:{userId:u.id}});await ctx.reply('متن پیام را ارسال کنید:');});
  bot.callbackQuery(new RegExp(`^admin:req:${kind}:conversation:(.+)$`),async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const id=ctx.match[1];const req=await getRequest(kind,id);if(!req)return;await openConversation(req.userId);await setSession(`admin:${ctx.from!.id}`,`admin_conv:${req.userId}`,{flow:'admin_conv',step:'text',data:{userId:req.userId}});await ctx.reply('گفت‌وگوی دوطرفه فعال شد. پیام بعدی شما برای کاربر ارسال می‌شود.');});
}

bot.callbackQuery('admin:deposits',async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const pending=await prisma.deposit.findMany({where:{status:'PENDING'},include:{user:true,networkRef:true},orderBy:{createdAt:'asc'},take:20});const kb=new InlineKeyboard().text('➕ ثبت واریزی','admin:deposit:new').row();if(!pending.length){await ctx.reply('واریزی در انتظار تأیید وجود ندارد.',{reply_markup:kb.addRow(backAdmin().inline_keyboard[0])});return;}for(const d of pending){await ctx.reply(`💰 <b>${d.trackingCode}</b>\nکاربر: ${d.user.telegramId.toString()}\nمبلغ: ${money(d.amount)} ${d.currency}\nشبکه: ${escapeHtml(d.network)}\nآدرس: <code>${escapeHtml(d.address)}</code>`,{parse_mode:'HTML',reply_markup:new InlineKeyboard().text('✅ تأیید',`admin:deposit:approve:${d.id}`).text('❌ رد',`admin:deposit:reject:${d.id}`)});}await ctx.reply('مدیریت واریزی‌ها',{reply_markup:kb});});
bot.callbackQuery('admin:deposit:new',async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;await setSession(`admin:${ctx.from!.id}`,'admin_deposit:user', {flow:'admin_deposit',step:'user',data:{}});await ctx.reply('Telegram numeric ID کاربر را وارد کنید:');});
bot.callbackQuery(/^admin:deposit:(approve|reject):(.+)$/,async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const action=ctx.match[1];const id=ctx.match[2];const d=await prisma.deposit.findUnique({where:{id},include:{user:true}});if(!d)return ctx.reply('واریزی پیدا نشد.');try{if(action==='approve')await approveDeposit(id,BigInt(ctx.from!.id));else await rejectDeposit(id,BigInt(ctx.from!.id));await notifyUser(d.user.telegramId,`واریزی ${d.trackingCode} ${action==='approve'?'تأیید شد و به موجودی شما اضافه شد ✅':'رد شد ❌'}`);await ctx.reply('انجام شد.',{reply_markup:backAdmin()});}catch(e){await ctx.reply('واریزی قبلاً پردازش شده یا خطایی رخ داده است.');}});

bot.callbackQuery('admin:balances',async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;await setSession(`admin:${ctx.from!.id}`,'admin_balance:user',{flow:'admin_balance',step:'user',data:{}});await ctx.reply('Telegram numeric ID کاربر را وارد کنید:');});
bot.callbackQuery('admin:wallets',async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const stats=await walletStats();const text=stats.length?stats.map(s=>`${s.network.currency}/${s.network.displayName}: کل ${s.total} | اختصاص‌یافته ${s.assigned} | آزاد ${s.available}`).join('\n'):'شبکه‌ای تنظیم نشده است.';const walletRows = await prisma.wallet.findMany({ include: { network: true, assignment: { include: { user: true } } }, orderBy: { createdAt: 'desc' }, take: 30 });
const kb = new InlineKeyboard().text('➕ افزودن آدرس','admin:wallet:add').row();
walletRows.forEach(w => kb.text(`${w.active?'🟢':'⚪️'} ${w.network.displayName} | ${w.address.slice(0,8)}…`, `admin:wallet:detail:${w.id}`).row());
kb.text('⬅️ پنل','admin:menu');
await ctx.reply(`🏦 وضعیت کیف پول‌ها:\n\n${text}\n\nمدیریت آدرس‌ها:`,{reply_markup:kb});});
bot.callbackQuery('admin:wallet:add',async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;await setSession(`admin:${ctx.from!.id}`,'admin_wallet:network',{flow:'admin_wallet',step:'network',data:{}});const ns=await prisma.network.findMany({where:{active:true}});const kb=new InlineKeyboard();ns.forEach(n=>kb.text(n.displayName,`admin:wallet:network:${n.id}`).row());await ctx.reply('شبکه را انتخاب کنید:',{reply_markup:kb});});
bot.callbackQuery(/^admin:wallet:network:(.+)$/,async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const s=await getSession(`admin:${ctx.from!.id}`);const p=s?.data as SessionPayload;const data=(p?.data??{}) as Record<string,string>;data.networkId=ctx.match[1];await setSession(`admin:${ctx.from!.id}`,'admin_wallet:address',{flow:'admin_wallet',step:'address',data});await ctx.reply('آدرس عمومی کیف پول را وارد کنید:');});

bot.callbackQuery(/^admin:wallet:detail:(.+)$/,async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const w=await prisma.wallet.findUnique({where:{id:ctx.match[1]},include:{network:true,assignment:{include:{user:true}}}});if(!w)return ctx.reply('کیف پول پیدا نشد.');const assigned=w.assignment?`کاربر: ${w.assignment.user.telegramId.toString()}\nتاریخ تخصیص: ${w.assignment.assignedAt.toLocaleString('fa-IR')}`:'آزاد';const kb=new InlineKeyboard().text(w.active?'⛔️ غیرفعال کردن':'🟢 فعال کردن',`admin:wallet:toggle:${w.id}`);if(w.assignment)kb.text('↩️ لغو تخصیص',`admin:wallet:unassign:${w.id}`);kb.row().text('⬅️ کیف پول‌ها','admin:wallets');await ctx.reply(`🏦 ${w.network.displayName}\nآدرس: <code>${escapeHtml(w.address)}</code>\n${assigned}`,{parse_mode:'HTML',reply_markup:kb});});
bot.callbackQuery(/^admin:wallet:toggle:(.+)$/,async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const w=await prisma.wallet.findUnique({where:{id:ctx.match[1]}});if(!w)return;await prisma.wallet.update({where:{id:w.id},data:{active:!w.active}});await ctx.reply('وضعیت کیف پول تغییر کرد.',{reply_markup:backAdmin()});});
bot.callbackQuery(/^admin:wallet:unassign:(.+)$/,async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const w=await prisma.wallet.findUnique({where:{id:ctx.match[1],},include:{assignment:true}});if(!w?.assignment)return ctx.reply('این کیف پول تخصیص ندارد.');await prisma.walletAssignment.delete({where:{id:w.assignment.id}});await ctx.reply('تخصیص لغو شد.',{reply_markup:backAdmin()});});

bot.callbackQuery('admin:networks',async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const ns=await prisma.network.findMany({orderBy:{displayName:'asc'}});const kb=new InlineKeyboard().text('➕ افزودن شبکه','admin:network:add').row();for(const n of ns)kb.text(`${n.active?'🟢':'⚪️'} ${n.displayName}`,`admin:network:toggle:${n.id}`).text('✏️',`admin:network:rename:${n.id}`).row();kb.addRow(backAdmin().inline_keyboard[0]);await ctx.reply('🌐 شبکه‌ها:',{reply_markup:kb});});
bot.callbackQuery('admin:network:add',async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;await setSession(`admin:${ctx.from!.id}`,'admin_network:name',{flow:'admin_network',step:'name',data:{}});await ctx.reply('نام فنی شبکه را وارد کنید (مثلاً TRC20):');});
bot.callbackQuery(/^admin:network:toggle:(.+)$/,async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const n=await prisma.network.findUnique({where:{id:ctx.match[1]}});if(n)await prisma.network.update({where:{id:n.id},data:{active:!n.active}});await ctx.reply('وضعیت شبکه تغییر کرد.',{reply_markup:backAdmin()});});
bot.callbackQuery(/^admin:network:rename:(.+)$/,async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;await setSession(`admin:${ctx.from!.id}`,'admin_network:rename',{flow:'admin_network',step:'rename',data:{id:ctx.match[1]}});await ctx.reply('نام نمایشی جدید شبکه را وارد کنید:');});

bot.callbackQuery('admin:teams',async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const ts=await prisma.team.findMany({orderBy:{name:'asc'}});const kb=new InlineKeyboard().text('➕ افزودن تیم','admin:team:add').row();for(const t of ts)kb.text(`${t.active?'🟢':'⚪️'} ${t.name}`,`admin:team:toggle:${t.id}`).text('✏️',`admin:team:rename:${t.id}`).row();kb.addRow(backAdmin().inline_keyboard[0]);await ctx.reply('👥 تیم‌ها:',{reply_markup:kb});});
bot.callbackQuery('admin:team:add',async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;await setSession(`admin:${ctx.from!.id}`,'admin_team:name',{flow:'admin_team',step:'name',data:{}});await ctx.reply('نام تیم را وارد کنید:');});
bot.callbackQuery(/^admin:team:toggle:(.+)$/,async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const t=await prisma.team.findUnique({where:{id:ctx.match[1]}});if(t)await prisma.team.update({where:{id:t.id},data:{active:!t.active}});await ctx.reply('وضعیت تیم تغییر کرد.',{reply_markup:backAdmin()});});
bot.callbackQuery(/^admin:team:rename:(.+)$/,async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;await setSession(`admin:${ctx.from!.id}`,'admin_team:rename',{flow:'admin_team',step:'rename',data:{id:ctx.match[1]}});await ctx.reply('نام جدید تیم را وارد کنید:');});

bot.callbackQuery('admin:messages',async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const cs=await prisma.conversation.findMany({where:{status:'OPEN'},include:{user:true},orderBy:{createdAt:'desc'},take:20});if(!cs.length)return ctx.reply('گفت‌وگوی بازی وجود ندارد.',{reply_markup:backAdmin()});for(const c of cs)await ctx.reply(`💬 کاربر ${c.user.telegramId.toString()}`,{reply_markup:new InlineKeyboard().text('ارسال پیام',`admin:conv:${c.userId}`).text('بستن',`admin:convclose:${c.userId}`)});});
bot.callbackQuery(/^admin:conv:(.+)$/,async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const userId=ctx.match[1];await openConversation(userId);await setSession(`admin:${ctx.from!.id}`,`admin_conv:${userId}`,{flow:'admin_conv',step:'text',data:{userId}});await ctx.reply('پیام بعدی شما برای کاربر ارسال می‌شود.',{reply_markup:new InlineKeyboard().text('بستن گفت‌وگو',`admin:convclose:${userId}`)});});
bot.callbackQuery(/^admin:convclose:(.+)$/,async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const userId=ctx.match[1];await closeConversation(userId);await clearSession(`admin:${ctx.from!.id}`);await ctx.reply('گفت‌وگو بسته شد.',{reply_markup:backAdmin()});});

bot.callbackQuery('admin:reports',async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const [users,ledger,requests,deposits]=await Promise.all([prisma.user.count(),prisma.ledgerTransaction.count(),prisma.ecardPurchaseRequest.count(),prisma.deposit.count()]);await ctx.reply(`📊 گزارش\n\nکاربران: ${users}\nتراکنش‌های دفترکل: ${ledger}\nدرخواست تهیه ایکارت: ${requests}\nواریزی‌ها: ${deposits}`,{reply_markup:backAdmin()});});
bot.callbackQuery('admin:settings',async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;await ctx.reply('⚙️ تنظیمات از طریق جدول BotSetting و عملیات مدیریتی قابل توسعه است. مقادیر امنیتی مانند توکن و کلید رمزنگاری فقط از Environment خوانده می‌شوند.',{reply_markup:backAdmin()});});

bot.on('message:text', async (ctx, next) => {
  if (!isAdmin(ctx) || !ctx.from) return next();
  const key=`admin:${ctx.from.id}`; const s=await getSession(key); const p=s?.data as SessionPayload; const data=(p?.data??{}) as Record<string,string>; const text=ctx.message.text.trim();
  if(s?.state?.startsWith('admin_message:')){const uid=data.userId;const user=await prisma.user.findUnique({where:{id:uid}});if(user){await notifyUser(user.telegramId,`💬 پیام مدیریت:\n${escapeHtml(text)}`);await saveMessage((await openConversation(uid)).id,uid,'ADMIN_TO_USER',text,ctx.message.message_id);await clearSession(key);await ctx.reply('پیام ارسال شد.');}return;}
  if(s?.state?.startsWith('admin_conv:')){const uid=data.userId;if(text==='/closeconv'){await closeConversation(uid);await clearSession(key);return ctx.reply('گفت‌وگو بسته شد.');}const user=await prisma.user.findUnique({where:{id:uid}});if(user){const c=await openConversation(uid);await saveMessage(c.id,uid,'ADMIN_TO_USER',text,ctx.message.message_id);await notifyUser(user.telegramId,`💬 پیام مدیریت:\n${escapeHtml(text)}`);return ctx.reply('ارسال شد.');}}
  if(s?.state==='admin_deposit:user'){data.userTelegramId=text;await setSession(key,'admin_deposit:amount',{flow:'admin_deposit',step:'amount',data});return ctx.reply('مبلغ واریزی به USDT:');}
  if(s?.state==='admin_deposit:amount'){const parsed=depositAmountSchema.safeParse(text);if(!parsed.success)return ctx.reply('مبلغ معتبر نیست.');data.amount=String(parsed.data);await setSession(key,'admin_deposit:network',{flow:'admin_deposit',step:'network',data});const ns=await prisma.network.findMany({where:{active:true}});const kb=new InlineKeyboard();ns.forEach(n=>kb.text(n.displayName,`admin:deposit:network:${n.id}`).row());return ctx.reply('شبکه:',{reply_markup:kb});}
  if(s?.state==='admin_deposit:address'){data.address=text;await setSession(key,'admin_deposit:tx',{flow:'admin_deposit',step:'tx',data});return ctx.reply('TX Hash را وارد کنید یا «-» بزنید:');}
  if(s?.state==='admin_deposit:tx'){data.txHash=text==='-'?'':text;await setSession(key,'admin_deposit:note',{flow:'admin_deposit',step:'note',data});return ctx.reply('یادداشت اختیاری یا «-»:');}
  if(s?.state==='admin_deposit:note'){data.note=text==='-'?'':text;const user=await prisma.user.findUnique({where:{telegramId:BigInt(data.userTelegramId)}});const network=await prisma.network.findUnique({where:{id:data.networkId}});const wallet=await prisma.wallet.findFirst({where:{networkId:data.networkId,address:data.address}});if(!user||!network||!wallet)return ctx.reply('کاربر، شبکه یا آدرس پیدا نشد.');const dep=await prisma.deposit.create({data:{trackingCode:await (async()=>{for(let i=0;i<10;i++){const c=`DEP-${Math.floor(100000+Math.random()*900000)}`;if(!(await prisma.deposit.findUnique({where:{trackingCode:c}})))return c;}throw new Error('tracking');})(),userId:user.id,walletId:wallet.id,networkId:network.id,network:network.displayName,currency:network.currency, address:wallet.address,amount:Number(data.amount),txHash:data.txHash||null,note:data.note||null}});await clearSession(key);await ctx.reply(`واریزی ${dep.trackingCode} با وضعیت PENDING ثبت شد.`);await notifyUser(user.telegramId,`💰 واریزی شما ثبت شد.\nکد: ${dep.trackingCode}\nمبلغ: ${money(dep.amount)} USDT\nوضعیت: در انتظار تأیید مدیریت`);return;}
  if(s?.state==='admin_wallet:address'){const wallet=await prisma.wallet.create({data:{networkId:data.networkId,address:text}});await clearSession(key);return ctx.reply(`آدرس اضافه شد: ${wallet.address}`,{reply_markup:backAdmin()});}
  if(s?.state==='admin_network:name'){const name=text.toUpperCase();await setSession(key,'admin_network:display',{flow:'admin_network',step:'display',data:{name}});return ctx.reply('نام نمایشی را وارد کنید (مثلاً USDT / TRC20):');}
  if(s?.state==='admin_network:display'){const name=data.name;await prisma.network.create({data:{name,displayName:text,currency:'USDT'}});await clearSession(key);return ctx.reply('شبکه ایجاد شد.',{reply_markup:backAdmin()});}
  if(s?.state==='admin_network:rename'){await prisma.network.update({where:{id:data.id},data:{displayName:text}});await clearSession(key);return ctx.reply('نام شبکه تغییر کرد.',{reply_markup:backAdmin()});}
  if(s?.state==='admin_team:name'){await prisma.team.create({data:{name:text}});await clearSession(key);return ctx.reply('تیم ایجاد شد.',{reply_markup:backAdmin()});}
  if(s?.state==='admin_team:rename'){await prisma.team.update({where:{id:data.id},data:{name:text}});await clearSession(key);return ctx.reply('نام تیم تغییر کرد.',{reply_markup:backAdmin()});}
  if(s?.state==='admin_balance:user'){const user=await prisma.user.findUnique({where:{telegramId:BigInt(text)}});if(!user)return ctx.reply('کاربر پیدا نشد.');const b=await balance(user.id);await clearSession(key);return ctx.reply(`موجودی ${text}: ${money(b)} USDT`,{reply_markup:backAdmin()});}
  return next();
});

bot.callbackQuery(/^admin:deposit:network:(.+)$/,async(ctx)=>{await ctx.answerCallbackQuery();if(!isAdmin(ctx))return;const key=`admin:${ctx.from!.id}`;const s=await getSession(key);const p=s?.data as SessionPayload;const data=(p?.data??{}) as Record<string,string>;data.networkId=ctx.match[1];await setSession(key,'admin_deposit:address',{flow:'admin_deposit',step:'address',data});await ctx.reply('آدرس کیف پول را وارد کنید:');});

bot.catch((err)=>{logger.error({err},'telegram bot error');});

function escapeHtml(s:string){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}

export { bot };
