import { InlineKeyboard } from 'grammy';
import { isAdmin } from '../middleware/admin';
import { Context } from 'grammy';

export function mainMenu(ctx: Context): InlineKeyboard {
  const kb = new InlineKeyboard()
    .text('🔗 اتصال اتاق کار', 'menu:workroom').row()
    .text('💳 چنچ ایکارت', 'menu:change').text('🪪 تهیه ایکارت', 'menu:purchase').row()
    .text('💰 واریز به کیف پول', 'menu:wallets').text('👛 موجودی کیف پول', 'menu:balance').row()
    .text('📋 پیگیری درخواست‌ها', 'menu:tracking').text('💬 پشتیبانی', 'menu:support');
  if (isAdmin(ctx)) kb.row().text('⚙️ پنل مدیریت', 'admin:menu');
  return kb;
}

export function cancelKeyboard() { return new InlineKeyboard().text('❌ لغو', 'flow:cancel'); }
