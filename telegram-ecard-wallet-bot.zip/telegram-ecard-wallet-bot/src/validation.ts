import { z } from 'zod';
import { normalizeDigits } from './utils/tracking';

const text = z.string().trim().min(1).max(500);
export const workroomSchema = z.object({
  irId: text.max(100), password: text.max(300), qAccountPassword: text.max(300), email: z.string().email().max(254),
  emailPassword: text.max(300), phoneNumber: text.max(50)
});
export const ecardChangeSchema = z.object({
  irId: text.max(100), email: z.string().email().max(254), phone: text.max(50), teamId: text,
  usdtAddress: text.max(300), networkId: text, ecardSerial: text.max(200), ecardPassword: text.max(300)
});
export const ecardPurchaseSchema = z.object({
  identityValue: text.max(200), email: z.string().email().max(254), phone: text.max(50), teamId: text,
  amount: z.preprocess((v) => Number(normalizeDigits(String(v))), z.number().finite().min(200).max(10000)), networkId: text
});
export const depositAmountSchema = z.preprocess((v) => Number(normalizeDigits(String(v))), z.number().finite().positive().max(1_000_000));
