import 'dotenv/config';
import { z } from 'zod';

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('production'),
  BOT_TOKEN: z.string().min(1),
  ADMIN_TELEGRAM_IDS: z.string().min(1),
  DATABASE_URL: z.string().min(1),
  ENCRYPTION_KEY: z.string().min(32),
  LOG_LEVEL: z.string().default('info'),
  APP_URL: z.string().optional().default(''),
  PORT: z.coerce.number().int().positive().default(3000)
});

export const env = envSchema.parse(process.env);

export const adminIds = new Set(
  env.ADMIN_TELEGRAM_IDS.split(',').map((v) => v.trim()).filter(Boolean).map((v) => BigInt(v))
);
