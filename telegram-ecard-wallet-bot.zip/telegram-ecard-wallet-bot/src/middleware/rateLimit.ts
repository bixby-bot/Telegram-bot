import { Context, NextFunction } from 'grammy';

const hits = new Map<number, number[]>();
const WINDOW_MS = 60_000;
const MAX = 30;

export async function rateLimit(ctx: Context, next: NextFunction): Promise<void> {
  const id = ctx.from?.id;
  if (!id) return next();
  const now = Date.now();
  const list = (hits.get(id) ?? []).filter((t) => now - t < WINDOW_MS);
  if (list.length >= MAX) {
    await ctx.reply('⏳ تعداد درخواست‌ها زیاد است. لطفاً یک دقیقه بعد دوباره تلاش کنید.');
    return;
  }
  list.push(now);
  hits.set(id, list);
  await next();
}
