import { Context, NextFunction } from 'grammy';
import { adminIds } from '../config';

export function isAdmin(ctx: Context): boolean {
  const id = ctx.from?.id;
  return id !== undefined && adminIds.has(BigInt(id));
}

export async function requireAdmin(ctx: Context, next: NextFunction): Promise<void> {
  if (!isAdmin(ctx)) {
    await ctx.reply('⛔️ دسترسی غیرمجاز است.');
    return;
  }
  await next();
}
